import { Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';

import { LayoutAdminComponent } from './layout-admin/layout-admin.components';
import { LayoutClienteComponent } from './layout-cliente/layout-cliente.component';

import { VeiculoListComponent } from './components/veiculos/veiculo-list/veiculo-list.component';
import { ClienteListComponent } from './components/clientes/cliente-list/cliente-list.component';

import { AuthGuard } from './core/auth.guard';
import { AdminGuard } from './core/admin.guard';

export const routes: Routes = [

  { path: '', redirectTo: 'login', pathMatch: 'full' },

  { path: 'login', component: LoginComponent },

  // ROTAS ADMIN
  {
    path: 'admin',
    component: LayoutAdminComponent,
    canActivate: [AuthGuard, AdminGuard],
    children: [
      { path: 'home', component: VeiculoListComponent },
      { path: 'clientes', component: ClienteListComponent }
    ]
  },

  // ROTAS CLIENTE
  {
    path: 'cliente',
    component: LayoutClienteComponent,
    canActivate: [AuthGuard],
    children: [
      { path: 'veiculos', component: VeiculoListComponent }
    ]
  },

  { path: '**', redirectTo: 'login' }
];
